import React, { Component } from 'react'

import Loop from './child/loop'
import Footer from './child/footer'

export default class Index extends Component {
    render() {
        return (
            <div>
                {/* 轮播图 */}
                <Loop/>
                {/* 底部 */}
                <Footer/>
            </div>
        )
    }
}
